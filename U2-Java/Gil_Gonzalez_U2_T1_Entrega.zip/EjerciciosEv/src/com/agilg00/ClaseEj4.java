package com.agilg00;

import java.util.Scanner;

public class ClaseEj4 {
    public static void main(String[] args) {
        int filas=0;
        char c='*';
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la altura ");
        filas = sc.nextInt();

        System.out.println("Introduce el asterisco para confirmar");
        c = sc.next().charAt(0);

        for (int i=0;i<filas;i++) {
            for (int j=0;j>filas+i;j++) {
                System.out.print(" ");
            }

            for (int j=0;j<=i*2;j++) {
                if (j==0 || j==i*2) {
                    System.out.print(c);
                } else {
                    System.out.print(" ");
                }

            }

            System.out.println();

        }
    }
}

