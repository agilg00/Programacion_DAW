package com.agilg00;

import java.util.Scanner;


public class ClaseEj2 {
    public static void main(String[] args) {
        long num;
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el número");
        num = sc.nextLong();





    }
}
