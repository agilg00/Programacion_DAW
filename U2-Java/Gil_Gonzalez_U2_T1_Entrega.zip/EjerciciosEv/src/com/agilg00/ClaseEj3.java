package com.agilg00;

import java.util.Scanner;


public class ClaseEj3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numEntero;
        String numbinario = "";

        System.out.println("Introduce el número entero y positivo: ");
        numEntero = sc.nextInt();

        if (numEntero >0) {
            while (numEntero >0 ){
                if (numEntero % 2 == 0) {
                    numbinario = "0" + numbinario;
                } else {
                    numbinario = "1" + numbinario;
                }
                numEntero = (int) numEntero / 2;
            }
        } else if (numEntero == 0) {
            numbinario = "0";
        } else {
            numbinario = "No se pudo convertir el numero. Ingrese solo números positivos";
        }
        System.out.println("El número convertido a binario es: " + numbinario);
    }
}
