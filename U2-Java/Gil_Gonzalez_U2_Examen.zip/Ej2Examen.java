package com.agilg00;

import java.util.Scanner;

public class Ej2Examen {
    public static void main(String[] args) {

        int numero;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Introduzca un número entero positivo y como mínimo de dos dígitos");
            numero = sc.nextInt();
            if (numero < 10) {
                System.out.println("Número erróneo, debe ser entero positivo y mínimo de dos dígitos");
            }
        } while (numero < 10);

        int aux = numero;
        int cont = 0;
        while (aux > 0) {
            aux /= 10;
            cont++;
        }

        int pos;
        do {
            System.out.println("Introduce la posición en la cual quiere partir eñ número");
            pos = sc.nextInt();
            if (pos < 2 || pos > cont) {
                System.out.println("Posición errónea, esta debe estar entre 2 y " + cont);
            }
        } while (pos < 2 || pos > cont);

        System.out.println();
        System.out.print("Los números partidos son el ");

        aux = numero;
        for (int i = pos; i <= cont; i++) {
            aux = aux / 10;
        }
        System.out.print(aux);
        System.out.print(" y el ");
        for (int i = pos; i <= cont; i++) {
            aux = aux * 10;
        }
        System.out.print(numero - aux);
    }
}



