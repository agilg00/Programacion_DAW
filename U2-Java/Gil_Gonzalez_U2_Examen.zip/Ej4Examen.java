package com.agilg00;

import java.util.Scanner;

public class Ej4Examen {
    public static void main(String[] args) {
        int num;
        int contador = 0;
        int min = 0;
        int max = 0;
        int suma = 0;
        Scanner sc = new Scanner(System.in);
        boolean primo;


        System.out.println("Introduzca números enteros positivos. Para parar el proceso, introduzca un número primo");

        do {
            num = sc.nextInt();
            if (num <= 0) {
                System.out.println("Erróneo, el número debe ser entero positivo");
                primo = false;
            } else {
                primo = true;
                for (int i = 2; i < num; i++) {
                    if (num % i == 0) {
                        primo = false;
                        break;
                    }
                }
                if (!primo) {
                    contador++;
                    suma = suma + num;

                    if (contador == 1) {
                        min = num;
                        max = num;
                    } else {
                        if (num > max) {
                            max = num;
                        }
                        if (num < min) {
                            min = num;
                        }
                    }
                } else {
                    System.out.println("RESULTADO");
                }
            }
        } while (num <= 0 || !primo);


        if (contador == 0) {
            System.out.println("Solo ha introducido un numero primo");
        } else {
            System.out.println("Ha introducido " + contador + " numeros no primos.");
            System.out.println("Máximo: " + max);
            System.out.println("Mínimo: " + min);
            System.out.println("Media: " + (double) suma / contador);

        }


    }
}
