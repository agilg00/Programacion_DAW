package com.agilg00;

import java.util.Scanner;

public class Ej3Examen {
    public static void main(String[] args) {

        long numero;
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el número");
        numero = sc.nextLong();

        String aparece = "";
        String noaparece = "";
        String numeroOriginal = String.valueOf(numero);

        for (int i = 0; i <= 9; i++) {
            if (numeroOriginal.contains(String.valueOf(i))) {
                aparece += i + " ";
            } else {
                noaparece += i + " ";
            }
        }
        System.out.println("Dígitos que aparecen en el número: " + aparece);
        System.out.println("Dígitos que no aparecen: " + noaparece);
    }
}
