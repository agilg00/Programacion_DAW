package com.agilg00;

import java.util.Scanner;

public class Ej1Examen {
    public static void main(String[] args) {

        int altura;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Introduce la altura, que debe ser un número impar mayor o igual a 5");
            altura = sc.nextInt();

            if (altura % 2 == 0 || altura < 5) {
                System.out.println("Error, la altura es incorrecta");
            }
        } while (altura % 2 == 0 || altura < 5);

            for (int i = 0; i < altura; i++) {
                for (int j = 0; j < 8; j++) {
                    if ((i == 0) || (i == altura - 1) || (i == altura / 2) || (j == 0) || (j == 7)) {
                        System.out.print("M");
                    } else {
                        System.out.print(" ");
                    }


                }
                System.out.println();
            }




    }
}
