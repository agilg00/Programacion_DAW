package com.agilg00;

public class Main {

    public static void main(String[] args) {


        Personajes p1 = new Personajes();

        p1.newPersonaje("Malfurion", true);
        p1.mostrarInfo();

        Magos m1 = new Magos(0);

        m1.newPersonaje("Valeera", true);


        m1.mostrarMago();

        Orcos o1 = new Orcos(2);

        o1.newPersonaje("Garrosh", false);
        o1.mostrarOrco();
        Hombres h1 = new Hombres();

        h1.newPersonaje("Uther", false);
        h1.mostrarInfo();

        Elfos e1 = new Elfos();

        e1.Elfo("Bosque");
        e1.newPersonaje("Elfo de la noche", true);

        e1.mostrarElfo();

        Enanos en1 = new Enanos(1.20);

        en1.newPersonaje("Marselo", false);

        en1.mostrarEnano();





	// write your code here
    }
}
