package com.agilg00;

public class Personajes {


    String mNombre;
    int mEnergia;
    int mAtaque;
    int mDefensa;
    boolean mEncantado;


    public void newPersonaje (String nombre, boolean encantado){

        int valorEnergia = (int) (Math.random()*1000);
        int valorAtaque = (int) (Math.random()*100);
        int valorDefensa = (int) (Math.random()*100);

        this.mNombre = nombre;
        this.mAtaque = valorAtaque;
        this.mEnergia = valorEnergia;
        this.mDefensa = valorDefensa;
        this.mEncantado = encantado;

    }

    public void borrarPersonaje (){

        if (this.mEnergia<=0){
            newPersonaje(null, false);
        }
    }
    public void mostrarInfo(){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Encantado: "+mEncantado);

    }


}

class Elfos extends Personajes implements Atacar{

    String mTipoElfo;



    public void Elfo(String tipoElfo) {
        this.mTipoElfo = tipoElfo;
    }

    public void mostrarElfo (){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Tipo de elfo: "+mTipoElfo);
        System.out.println("Encantado: "+mEncantado);

    }

    @Override
    public String toString() {
        return "Elfos{" +
                "mTipoElfo='" + mTipoElfo + '\'' +
                '}';
    }

    public void atacarPersonaje(){

        System.out.println(mNombre+" ATACANDO!");

    }

}

class Orcos extends Personajes implements Atacar{

    int mTonelaje;

    public Orcos(int mTonelaje) {
        this.mTonelaje = mTonelaje;
    }
    public void atacarPersonaje(){

        System.out.println(mNombre+" ATACANDO!");

    }
    public void mostrarOrco (){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Tonelaje del Orco: "+mTonelaje);
        System.out.println("Encantado: "+mEncantado);

    }

    @Override
    public String toString() {
        return "Orcos{" +
                "mTonelaje=" + mTonelaje +
                '}';
    }
}
class Enanos extends Personajes implements Atacar{

    double mAltura;

    public Enanos(double mAltura) {
        this.mAltura = mAltura;
    }
    public void atacarPersonaje(){

        System.out.println(mNombre+" ATACANDO!");

    }
    public void mostrarEnano (){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Altura del enano: "+mAltura);
        System.out.println("Encantado: "+mEncantado);

    }

    @Override
    public String toString() {
        return "Enanos{" +
                "mAltura=" + mAltura +
                '}';
    }
}
class Hombres extends Personajes implements Atacar{

    public void atacarPersonaje(){

        System.out.println(mNombre+" ATACANDO!");

    }


}

class Guerreros extends Hombres{
    int mEdad;

    public Guerreros(int mEdad) {
        this.mEdad = mEdad;
    }
    public void mostrarGuerrero (){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Edad: "+mEdad);
        System.out.println("Encantado: "+mEncantado);

    }

    @Override
    public String toString() {
        return "Guerreros{" +
                "mEdad=" + mEdad +
                '}';
    }
}
class Magos extends Hombres implements Magia{
    int mLongitudBarba;

    public Magos(int mLongitudBarba) {
        this.mLongitudBarba = mLongitudBarba;
    }
    public void EncantarPersonaje(){


    }
    public void mostrarMago (){
        System.out.println("Nombre del personaje: "+mNombre);
        System.out.println("Puntos de energia: "+mEnergia);
        System.out.println("Puntos de ataque: "+mAtaque);
        System.out.println("Puntos de defensa: "+mDefensa);
        System.out.println("Longitud de la barba: "+mLongitudBarba);
        System.out.println("Encantado: "+mEncantado);

    }

    @Override
    public String toString() {
        return "Magos{" +
                "mLongitudBarba=" + mLongitudBarba +
                '}';
    }
}
interface Atacar{

     private void atacarPersonaje(){

    }
}
interface Magia{
    private void Encantar(){

    }
    private void Desencantar(){

    }
}