package com.agilg00;

import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) {

        /*Aquí realmenteno sé cómo hacer para que aparezcan los números consecutivamente a los lados y las letras arriba
        y abajo, por lo que uso un marco hecho con asteriscos
         */
        /* El ejercicio en sí no está hecho, solo aparece marcado con una x la posición del alfil que indica el usario
        dentro del cuadro de asteriscos (Oye almenos esto lo manejo y lo entiendo)
        El problema viene al indicar hacia dónde puede moverse el alfil. Sé que sólo puede hacerlo de forma diagonal, y que
        sé hacer que muestre 2 diagonales en forma de cruz en las condiciones, pero no sé hacer que partan desde el punto donde
        se encuentra el alfil.
        O puede que también esté haciendo cosas innecesarias *emoji pensativo*
         */

        int[][] tablero = new int[9][9];

        Scanner sc = new Scanner(System.in);

        int a;
        int n;

        do {

            System.out.println("Introduce la posición 'a' del alfil ");
            a = sc.nextInt();
            System.out.println("Introduce la posición 'n' del alfil ");
            n = sc.nextInt();

            int[][] posicion = new int[a][n];

            for (int i = 0; i < tablero.length; i++) {
                for (int j = 0; j < tablero.length; j++) {
                    if (i == 0 || i == 8 || j == 0 || j == 8) {
                        System.out.print(" * ");
                    } else if (i == n && j == a) {
                        System.out.print(" X ");
                    } else {
                        System.out.print(" - ");
                    }

                }
                System.out.println();
            }
            System.out.println("El alfil podrá moverse hacia ");


        } while (a > 0 || n > 0);


    }
}
