package com.agilg00;

import java.util.Arrays;
import java.util.Scanner;

public class Ej2 {

    public static int[] insertarValor (int[] v1, int valor, int posicion){

        int[] vecInt = {1,2,3,4,5};

        for (int i=0; i<posicion; i++){
            vecInt[i] = v1[valor];
        }
        System.out.println();

        return vecInt;


    }
    public static void main(String[] args) {


        int valor;
        int pos;

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el valor ");
        valor = sc.nextInt();
        System.out.println("Introduce la posicion ");
        pos = sc.nextInt();

        System.out.print(insertarValor(new int[10],valor, pos));



    }
}
