package com.agilg00;

public class Ej4 {
    public static void main(String[] args) {

        /*Empezamos mal que no recuerdo como se hacía para indicar si un número es primo.
        Evidentemente sé que sólo puede dividirse entre sí mismo y la unidad, pero no se
        como indicarlo por aquí.
         */


    }
}
