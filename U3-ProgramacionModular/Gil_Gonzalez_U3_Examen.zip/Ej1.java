package com.agilg00;

import java.util.Arrays;
import java.math.MathContext;
import java.util.Scanner;

public class Ej1 {

    public static int maxMatriz(int[][] v) {

        /*
        Juan Diego, le estaría agradecido si lee el siguiente comentario:


        Aún no manejo las funciones, enserio, es algo que llevo intentando desde que empezamos y no logro
        manejarlo del todo.
        Quizá sea el hecho de que no se me dá muy bien las matemáticas, y por eso en estos temas se me hace
        muy tedioso, tanto como hacer una funcion que me diga si un número es primo (ya se que se hizo en clase, pero
        no encuentro tampoco la manera de razonarlo para hacerlo de nuevo)

        No quiero que esto suene a excusa de que no he estudiado mucho, de hecho trato de ponerme todos los días un ratito
        para tratar de entender todo esto,
        pero cada vez que no logro entender algo me llega fácilmente la frustración y cierro el programa

        Creo que debería empezar desde el principio (lo sé, voy un poco tarde) para tratar de entender las cosas mas básicas,
        que hasta ahora las uso sin saber prácticamente.

        Espero no haberte hecho perder mucho tiempo corrigiendo esto.
        Un saludo

         */

        int a;
        int b;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce el valor de a ");
        a = sc.nextInt();
        System.out.println("Introduce el valor de b ");
        b = sc.nextInt();

        return v[a][b];




    }

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        int a;
        int b;
        System.out.println("Introduce los valores de la matriz");

        System.out.println("Introduce el valor de a ");
        a = sc.nextInt();
        System.out.println("Introduce el valor de b ");
        b = sc.nextInt();


        int[][] dimension = new int[a][b];

        for (int i=0; i<dimension.length;i++){
            for (int j=0; j<dimension[i].length; j++){
                dimension[i][j] = sc.nextInt();

                System.out.print(dimension[i][j]);

            }
        }
        System.out.println();





    }
}
