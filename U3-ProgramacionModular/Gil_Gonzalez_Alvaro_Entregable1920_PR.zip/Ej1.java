package com.agilg00;

import java.util.Scanner;

public class Ej1 {

    public static void main(String[] args) {
        // Un restaurante nos ha encargado una aplicación para colocar a los clientes en
        //sus mesas. En una mesa se pueden sentar de 0 (mesa vacía) a 4 comensales
        //(mesa llena). Cuando llega un cliente se le pregunta cuántos son. De momento
        //el programa no está preparado para colocar a grupos mayores a 4, por tanto, si
        //un cliente dice por ejemplo que son un grupo de 6, el programa dará el mensaje
        //“Lo siento, no admitimos grupos de 6, haga grupos de 4 personas
        //como máximo e intente de nuevo”. Para el grupo que llega, se busca
        //siempre la primera mesa libre (con 0 personas). Si no quedan mesas libres, se
        //busca donde haya un hueco para todo el grupo, por ejemplo si el grupo es de
        //dos personas, se podrá colocar donde haya una o dos personas. Inicialmente,
        //las mesas se cargan con valores aleatorios entre 0 y 4. Cada vez que se sientan
        //nuevos clientes se debe mostrar el estado de las mesas. Los grupos no se
        //pueden romper aunque haya huecos sueltos suficientes. El funcionamiento del
        //programa se ilustra a continuación




        Scanner sc = new Scanner(System.in);
        int[] mesas = new int[10];

        int ocupacion;
        int mesavacia = 0;


        do {
            System.out.println("Cuantos son? :");
            ocupacion = sc.nextInt();
            if (ocupacion > 4) {
                System.out.println("Lo siento, no tenemos mesa para más de 4, tendrán que compartir mesa");
            } else {
                System.out.println("Adelante, sígame a la mesa " + mesavacia);
            }


            for (int i = 0; i < mesas.length; i++) {
                System.out.print(mesas[i]+" | ");
            }
            System.out.println();
            for (int i = 1; i < 10; i++) {
                mesas[i] = (int) (Math.random()*4+1);
            }
            System.out.println();
        } while (ocupacion > -1);
    }


}


