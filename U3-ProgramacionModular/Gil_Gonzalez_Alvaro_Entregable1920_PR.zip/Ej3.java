package com.agilg00;

import java.util.Arrays;

public class Ej3 {

    public int[] filtraCon7(int x[]) {
        String contiene7 = "7";
        String numero = toString();


        if (x.length == 7) {
            return x;
        }
        if (numero.contains(contiene7)) {
            System.out.print(Arrays.toString(x));
        }

        return filtraCon7(x);


    }

    public static void main(String[] args) {
        //public int[] filtraCon7(int x[]) // Devuelve un array con todos los números
        //                                 // que contienen el 7 (por ej. 7, 27, 782)
        //                                 // que se encuentren en otro array que se
        //                                 // pasa como parámetro. El tamaño del array
        //                                 // que se devuelve será menor o igual al
        //                                // que se pasa como parámetro.
        //
        //Utiliza esta función en un programa para comprobar que funcionan bien. Para
        //que el ejercicio resulte más fácil, las repeticiones de números que contienen
        //7 se conservan; es decir, si en el array x el número 875 se repite 3 veces, en
        //el array devuelto también estará repetido 3 veces. Si no existe ningún número
        //que contiene 7 en el array x, se devuelve un array con el número -1 como único
        //elemento.


    }
}
