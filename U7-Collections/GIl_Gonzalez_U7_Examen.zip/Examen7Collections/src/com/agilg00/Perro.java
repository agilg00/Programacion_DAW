package com.agilg00;

public class Perro {

    String mNombrePerro;
    int mEdadPerro;
    double mPesoPerro;
    boolean mVacuna;
    String mPropietario;
    String RazaPerro;



    public Perro(String nombrePerro, int edadPerro, double pesoPerro, boolean vacuna, String propietario){

        this.mNombrePerro = nombrePerro;
        this.mEdadPerro = edadPerro;
        this.mPesoPerro = pesoPerro;
        this.mVacuna = vacuna;
        this.mPropietario = propietario;


    }

    public String getmNombrePerro() {
        return mNombrePerro;
    }

    public void setmNombrePerro(String mNombrePerro) {
        this.mNombrePerro = mNombrePerro;
    }

    Perro(){

    }


    public void disqualifyDog(String nombrePerro){




    }







}
