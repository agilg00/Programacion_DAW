package com.agilg00;

public enum RazaPerro {


    PastorAleman, Pekines, Chihuahua, Bodeguero




}
