package com.agilg00;

public class Propietario {

    String mNombre;
    String mApellidos;
    String mNumSSC;
    String mPaisOrigen;



}
